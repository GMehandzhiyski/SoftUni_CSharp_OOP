﻿using System;

namespace ValidationAttributes
{
    public static class Validator
    {
        public static bool IsValid(object obj)
        {
           Type type = obj.GetType();

             
            return default;
        }
    }
}
