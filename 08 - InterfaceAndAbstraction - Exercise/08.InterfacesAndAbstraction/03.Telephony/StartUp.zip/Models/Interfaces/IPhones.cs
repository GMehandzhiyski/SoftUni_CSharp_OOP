﻿
namespace Telephony.Models.Interfaces
{
    public interface IPhones
    {
        string Call(string phoneNumber);
    }
}
