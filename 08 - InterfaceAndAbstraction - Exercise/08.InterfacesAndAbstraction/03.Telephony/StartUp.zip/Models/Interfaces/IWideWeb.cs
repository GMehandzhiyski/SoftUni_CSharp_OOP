﻿namespace Telephony.Models.Interfaces
{
    public interface IWideWeb
    {

        string Browse(string url);
    }
}
