﻿

namespace BorderControl.Models.Interfaces
{
    public interface ICitizen
    {
        public string Name { get;}
        public int Age { get;}
    }
}
