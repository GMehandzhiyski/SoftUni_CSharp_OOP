﻿using HighwayToPeak.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighwayToPeak.Models
{
    public class Peak : IPeak
    {
        private string name;
        private int elevation;
        private string difficultyLevel;
  
        public string Name => throw new NotImplementedException();

        public int Elevation => throw new NotImplementedException();

        public string DifficultyLevel => throw new NotImplementedException();

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
