﻿using HighwayToPeak.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighwayToPeak.Models
{
    public abstract class Climber : IClimber
    {

        public string Name => throw new NotImplementedException();

        public int Stamina => throw new NotImplementedException();

        public IReadOnlyCollection<string> ConqueredPeaks => throw new NotImplementedException();

        public void Climb(IPeak peak)
        {
            throw new NotImplementedException();
        }

        public void Rest(int daysCount)
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
