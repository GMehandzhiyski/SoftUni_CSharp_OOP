﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Models
{
    public class LaserRadar : Supplement
    {
        //private readonly int LaserRadarInterfaceStandart = 20_082;
        //private readonly int LaserRadarBatteryUsage = 10_000;
        //public LaserRadar(int LaserRadarInterfaceStandart, int LaserRadarBatteryUsage) : 
        //    base(LaserRadarInterfaceStandart, LaserRadarBatteryUsage)
        //{
        //}
    }
}
