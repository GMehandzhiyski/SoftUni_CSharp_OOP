﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Models
{
    public class SpecializedArm : Supplement
    {
        //private readonly int SpecializedArmInterfaceStandard = 10_045;
        //private readonly int SpecializedArmBatteryUsage = 10_000;

        //public SpecializedArm(int SpecializedArmInterfaceStandard, int SpecializedArmBatteryUsage) 
        //    : base(SpecializedArmInterfaceStandard, SpecializedArmBatteryUsage)
        //{
        //}
    }
}
