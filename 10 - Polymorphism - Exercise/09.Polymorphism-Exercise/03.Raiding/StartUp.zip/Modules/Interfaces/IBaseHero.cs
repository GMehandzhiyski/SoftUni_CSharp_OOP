﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Raiding.Modules.Interfaces
{
    public interface IBaseHero
    {
        string Name { get; }
        int Power { get; }

        public string CastAbility();
    }
}
