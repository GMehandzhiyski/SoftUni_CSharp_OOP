﻿using System.Globalization;
using Vehicles.Core.Interfaces;
using Vehicles.Factories.Interfaces;
using Vehicles.IO.Interfaces;
using Vehicles.Models.Interfaces;

namespace Vehicles.Core
{
    public class Engine : IEngine
    {
        private readonly IReader reader;
        private readonly IWriter writer;
        private readonly IVehicleFactory vehicleFactory;

        private readonly ICollection<IVehicle> vehicles;
        public Engine(IReader reader, IWriter writer, IVehicleFactory vehicleFactory)
        {
            this.reader = reader;
            this.writer = writer;
            this.vehicleFactory = vehicleFactory;
            vehicles = new List<IVehicle>();

          
        }
        public void Run()
        {


            // business Logic

            vehicles.Add(CreateVehicle());
            vehicles.Add(CreateVehicle());
            vehicles.Add(CreateVehicle());

            int nLine = int.Parse(reader.ReadLine());

            for (int i = 0; i < nLine; i++)
            {
                try
                {
                    ProcessCommand();
                }
                catch (Exception ex)
                {

                    writer.WriteLine(ex.Message);
                }
            }

            foreach (var vehicle in vehicles)
            {
                writer.WriteLine(vehicle.ToString());
            }
        }

        private IVehicle CreateVehicle()
        {

            string[] vehicleInput = reader.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            IVehicle vehicle = vehicleFactory.Create(vehicleInput[0], double.Parse(vehicleInput[1]), double.Parse(vehicleInput[2]), double.Parse(vehicleInput[3]));
        
            return vehicle;
        }

        private void ProcessCommand()
        {
            string[] commandInput = reader.ReadLine()
                   .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            string method = commandInput[0];
            string type = commandInput[1];
            double value = double.Parse(commandInput[2]);

            IVehicle vehicle = vehicles.FirstOrDefault(c => c.GetType().Name == type);

            if (method == "Drive" 
                || method == "DriveEmpty")
            {
                writer.WriteLine(vehicle.Driving(value));
            }
            else if (method == "Refuel")
            {
                vehicle.Refueling(value);
            }
        }
    }



}
