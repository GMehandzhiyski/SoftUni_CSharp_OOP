﻿using System;

[SoftUni("Dancho")]
class Program
{
    [SoftUni("Yovcho")]
    static void Main(string[] args)
    {
        Console.WriteLine("Hello World!");
    }
}