﻿

namespace PlayersAndMonsters
{
    public abstract class Elf : Hero
    {
        protected Elf(string username, int level) 
            : base(username, level)
        {
        }
    }
}
