﻿

namespace PlayersAndMonsters
{
    public abstract class DarkWizard : Wizard
    {
        protected DarkWizard(string username, int level) 
            : base(username, level)
        {
        }
    }
}
