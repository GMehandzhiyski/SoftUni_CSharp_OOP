﻿
namespace PlayersAndMonsters
{
    public abstract class DarkKnight : Knight
    {
        protected DarkKnight(string username, int level) 
            : base(username, level)
        {
        }
    }
}
