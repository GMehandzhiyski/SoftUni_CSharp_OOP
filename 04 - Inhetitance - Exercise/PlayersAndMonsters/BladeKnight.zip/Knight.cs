﻿

namespace PlayersAndMonsters
{
    public abstract class Knight : Hero
    {
        protected Knight(string username, int level) 
            : base(username, level)
        {
        }
    }
}
