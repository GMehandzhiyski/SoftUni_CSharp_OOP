﻿

namespace PlayersAndMonsters
{
    public abstract class Wizard : Hero
    {
        protected Wizard(string username, int level) 
            : base(username, level)
        {
        }
    }
}
