﻿

namespace Zoo
{
    public abstract class Mammal : Animal
    {
        protected Mammal(string name) 
            : base(name)
        {
        }
    }
}
